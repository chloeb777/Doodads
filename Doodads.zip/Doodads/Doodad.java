class Doodad
{
  private double myNum;
  public Doodad()
  {
    myNum = 0;
  }
  public double getNum(){
    return myNum;
  }
  public void setNum(double n){
    myNum = n;
  }
}
